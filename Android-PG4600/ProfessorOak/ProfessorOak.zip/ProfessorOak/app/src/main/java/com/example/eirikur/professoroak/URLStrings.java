package com.example.eirikur.professoroak;

/**
 * Created by Eirikur on 05-Jun-16.
 */
public class URLStrings {
    String capture = "https://locations.lehmann.tech/pokemon/";
    String locationsUrl = "https://locations.lehmann.tech/locations";
    String highScoreUrl = "https://locations.lehmann.tech/scores";

    public URLStrings(){

    }

    public String getCapture(){
        return capture;
    }

    public String getLocationsUrl(){
        return locationsUrl;
    }

    public String getHighScoreUrl(){
        return highScoreUrl;
    }
}
