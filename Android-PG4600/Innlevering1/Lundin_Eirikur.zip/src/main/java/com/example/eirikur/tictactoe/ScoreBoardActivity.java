package com.example.eirikur.tictactoe;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class ScoreBoardActivity extends AppCompatActivity {

    private ListView listView;

    private String name;
    private static ArrayList<String> winners = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score_board);

        initViews();

        Bundle extras = getIntent().getExtras();
        if(extras != null){
            name = extras.getString("playerName");
        }

        addToArray(name);
        initAdapters();
    }

    private void initAdapters() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, winners);
        listView.setAdapter(adapter);
    }

    private void initViews() {
        listView = (ListView) findViewById(R.id.scoreView);
    }

    public void startNewGameFromScoreBoard(View view){
        Intent intent = new Intent(ScoreBoardActivity.this, GreetingActivity.class);
        startActivity(intent);
    }

    public void addToArray(String name){
        DateFormat timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();

        String tmp = "The winner is " + name + "\n" +
                "And the time was " + timeStamp.format(date);

        winners.add(tmp);
    }

}
