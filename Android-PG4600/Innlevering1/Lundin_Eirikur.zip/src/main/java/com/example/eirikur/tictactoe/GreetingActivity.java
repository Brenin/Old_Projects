package com.example.eirikur.tictactoe;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

public class GreetingActivity extends AppCompatActivity {

    private EditText textOne;
    private EditText textTwo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_greeting);

        textOne = (EditText) findViewById(R.id.playerOne);
        textTwo = (EditText) findViewById(R.id.playerTwo);
    }

    public void startNewGame(View view){
        Intent intent = new Intent(GreetingActivity.this, MainActivity.class);

        String nameOne = String.valueOf(textOne.getText());
        String nameTwo = String.valueOf(textTwo.getText());

        intent.putExtra("playerOne", nameOne);
        intent.putExtra("playerTwo", nameTwo);

        startActivity(intent);
    }

    public void goToScoreBoardFromStart(View view){
        Intent intent = new Intent(GreetingActivity.this, ScoreBoardActivity.class);
        startActivity(intent);
    }
}
