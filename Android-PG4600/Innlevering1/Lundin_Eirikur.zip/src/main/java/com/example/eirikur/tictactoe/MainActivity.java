package com.example.eirikur.tictactoe;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    int rows = 3, columns = 3, turn = 0;
    private boolean winner = false;
    private boolean playerOne = true;

    private String nameOne;
    private String nameTwo;

    Button topL, topM, topR, centerL, centerM, centerR, bottomL, bottomM, bottomR;
    Button[][] bArray = new Button[rows][columns];
    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Bundle extras = getIntent().getExtras();
        if(extras != null){
            nameOne = extras.getString("playerOne");
            nameTwo = extras.getString("playerTwo");
        }

        setPlayerName();
        linkingButtons();

    }

    private void setPlayerName() {
        editText = (EditText) findViewById(R.id.overView);
        editText.setText(nameOne + "/" + nameTwo);
    }

    public void goToScoreBoard(View view){
        Intent intent = new Intent(MainActivity.this, ScoreBoardActivity.class);
        startActivity(intent);
    }

    private void startNewGame() {
        Intent intent = new Intent(MainActivity.this, MainActivity.class);
        turn = 0;

        intent.putExtra("playerOne", nameOne);
        intent.putExtra("playerTwo", nameTwo);

        startActivity(intent);
    }

    public void linkingButtons(){
        topL = (Button) findViewById(R.id.topLeft);
        topM = (Button) findViewById(R.id.topMiddle);
        topR = (Button) findViewById(R.id.topRight);
        centerL = (Button) findViewById(R.id.centerLeft);
        centerM = (Button) findViewById(R.id.centerMiddle);
        centerR = (Button) findViewById(R.id.centerRight);
        bottomL = (Button) findViewById(R.id.bottomLeft);
        bottomM = (Button) findViewById(R.id.bottomMiddle);
        bottomR = (Button) findViewById(R.id.bottomRight);

        bArray[0][0] = topL;
        bArray[0][1] = topM;
        bArray[0][2] = topR;

        bArray[1][0] = centerL;
        bArray[1][1] = centerM;
        bArray[1][2] = centerR;

        bArray[2][0] = bottomL;
        bArray[2][1] = bottomM;
        bArray[2][2] = bottomR;

        addEventListeners();
    }

    public void addEventListeners(){
        for(int i = 0; i < rows; i++){
            for(int j = 0; j < columns; j++){
                bArray[i][j].setOnClickListener(this);
            }
        }
    }

    @Override
    public void onClick(View v) {
        Button b = (Button) v;
        playerChoice(b);
    }

    private void playerChoice(Button b) {
        if(playerOne){
            b.setText("X");
        } else {
            b.setText("O");
        }
        b.setClickable(false);
        turn++;

        checkForHorizontalWinner();
        checkForVerticalWinner();
        checkForDiagonalWinner();

        if(winner){
            if(playerOne){
                String tmp = nameOne + " wins!";
                toast(tmp);
                registerWinning();
            } else {
                String tmp = nameTwo + " wins!";
                toast(tmp);
                registerWinning();
            }
        }

        playerOne = !playerOne;

        if(turn == 9 && winner == false){
            toast("It's a tie!");
            Intent intent = new Intent(MainActivity.this, ScoreBoardActivity.class);

            intent.putExtra("playerName", "It's a tie");
            startActivity(intent);
        }
    }

    private void registerWinning() {
        Intent intent = new Intent(MainActivity.this, ScoreBoardActivity.class);

        if(playerOne){
            intent.putExtra("playerName", nameOne);
        } else {
            intent.putExtra("playerName", nameTwo);
        }

        startActivity(intent);
    }

    private void toast(String text) {
        Toast.makeText(getApplicationContext(), text, Toast.LENGTH_SHORT).show();
    }

    public void checkForHorizontalWinner(){
        if (bArray[0][0].getText() == bArray[0][1].getText() && bArray[0][0].getText() == bArray[0][2].getText()
                && !bArray[0][0].isClickable())
            winner = true;
        else if (bArray[1][0].getText() == bArray[1][1].getText() && bArray[1][0].getText() == bArray[1][2].getText()
                && !bArray[1][0].isClickable())
            winner = true;
        else if (bArray[2][0].getText() == bArray[2][1].getText() && bArray[2][0].getText() == bArray[2][2].getText()
                && !bArray[2][0].isClickable())
            winner = true;
    }

    public void checkForVerticalWinner(){
        if (bArray[0][0].getText() == bArray[1][0].getText() && bArray[0][0].getText() == bArray[2][0].getText()
                && !bArray[0][0].isClickable())
            winner = true;
        else if (bArray[0][1].getText() == bArray[1][1].getText() && bArray[0][1].getText() == bArray[2][1].getText()
                && !bArray[0][1].isClickable())
            winner = true;
        else if (bArray[0][2].getText() == bArray[1][2].getText() && bArray[0][2].getText() == bArray[2][2].getText()
                && !bArray[0][2].isClickable())
            winner = true;
    }

    public void checkForDiagonalWinner(){
        if (bArray[0][0].getText() == bArray[1][1].getText() && bArray[0][0].getText() == bArray[2][2].getText()
                && !bArray[0][0].isClickable())
            winner = true;
        else if (bArray[0][2].getText() == bArray[1][1].getText() && bArray[0][2].getText() == bArray[2][0].getText()
                && !bArray[2][0].isClickable())
            winner = true;
    }
}
