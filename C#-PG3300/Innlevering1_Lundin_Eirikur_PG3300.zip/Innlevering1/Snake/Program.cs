﻿// Refactored by Eirikur Lundin for PG3300 - Software Design

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace Snake {

	class Program {

		static void Main(string[] args) {

			// Variables
			var gameIsOver = false;
			var gameIsPaused = false;
			var spotIsOccupied = false;
			var boardWidth = Console.WindowWidth;
			var boardHeight = Console.WindowHeight;
			var newDirection = 2; // 0 = up, 1 = right, 2 = down, 3 = left
			var lastElementInSnake = newDirection;

			Random rng = new Random();
			Coord coord = new Coord();
			Stopwatch timer = new Stopwatch();
			List<Coord> snakeContent = new List<Coord>();
			
			GUI gui = new GUI();
			ApplesObject spawnFirstApple = new ApplesObject(rng, coord, boardHeight, boardWidth, snakeContent);
			HelpfullMethods.InitialiseSnake(snakeContent);

			timer.Start();

			// Gameloop
			while (!gameIsOver) {
				if (Console.KeyAvailable) {
					ConsoleKeyInfo keyUsed = Console.ReadKey(true);

					newDirection = HelpfullMethods.MovementDirection(keyUsed, newDirection, lastElementInSnake);

					gameIsOver = HelpfullMethods.DoYouWannaQuit(keyUsed, gameIsOver);

					gameIsPaused = HelpfullMethods.DoYouWannaPause(keyUsed, gameIsPaused);
					
				}

				if (!gameIsPaused) {
					if (timer.ElapsedMilliseconds < 100)
						continue;
					timer.Restart();
					Coord snakeTail = new Coord(snakeContent.First());
					Coord snakeHead = new Coord(snakeContent.Last());
					Coord newHead = new Coord(snakeHead);

					newHead = HelpfullMethods.WhereToPlaceNewHead(newDirection, newHead);

					if (newHead.X == coord.X && newHead.Y == coord.Y) {
						while (true) {
							spotIsOccupied = HelpfullMethods.IsSpawnPointInsideSnake(coord, boardWidth,	boardHeight, snakeContent, rng);
							break;
						}
					}					
					gameIsOver = HelpfullMethods.DidYouHitSomething(spotIsOccupied, gameIsOver, snakeContent, newHead, 
																		boardWidth, boardHeight);

					if (!gameIsOver) {
						spotIsOccupied = HelpfullMethods.SpawnNewHeadAndApple(snakeHead, snakeContent, newHead, spotIsOccupied, 
																				snakeTail, coord, rng, boardWidth, boardHeight);
						lastElementInSnake = newDirection;
					}
				}
			}
		}
	}
}