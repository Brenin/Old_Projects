﻿// Refactore by Eirikur Lundin for PG3300 - Software Design

using System;

namespace Snake {
	class GUI {

		public GUI() {
			Console.CursorVisible = false;
			Console.Title = "Westerdals Oslo ACT - SNAKE";
			Console.ForegroundColor = ConsoleColor.Green;
			Console.SetCursorPosition(10, 10);
			Console.Write("@");
		}
    }
}