﻿// Refactored by Eirikur Lundin for PG3300 - Software Design

using System;
using System.Collections.Generic;

namespace Snake {
	class HelpfullMethods {

		public static void InitialiseSnake(List<Coord> snakeContent) {

			for (var i = 0; i < 5; i++) {
				snakeContent.Add(new Coord(10, 10));
			}
		}

		public static int MovementDirection(ConsoleKeyInfo keyUsed, int newDirection, int lastElementInSnake) {

			if (keyUsed.Key == ConsoleKey.UpArrow && lastElementInSnake != 2)
				newDirection = 0;
			else if (keyUsed.Key == ConsoleKey.RightArrow && lastElementInSnake != 3)
				newDirection = 1;
			else if (keyUsed.Key == ConsoleKey.DownArrow && lastElementInSnake != 0)
				newDirection = 2;
			else if (keyUsed.Key == ConsoleKey.LeftArrow && lastElementInSnake != 1)
				newDirection = 3;

			return newDirection;
		}

		public static bool DoYouWannaQuit(ConsoleKeyInfo keyUsed, bool gameIsOver) {

			if (keyUsed.Key == ConsoleKey.Escape)
				gameIsOver = true;

			return gameIsOver;
		}

		public static bool DoYouWannaPause(ConsoleKeyInfo keyUsed, bool gameIsPaused) {

			if (keyUsed.Key == ConsoleKey.Spacebar) 
				gameIsPaused = !gameIsPaused;
				
			return gameIsPaused;
		}

		public static Coord WhereToPlaceNewHead(int newDirection, Coord newHead) {

			switch (newDirection) {
				case 0:
				newHead.Y -= 1;
				break;
				case 1:
				newHead.X += 1;
				break;
				case 2:
				newHead.Y += 1;
				break;
				default:
				newHead.X -= 1;
				break;
			}

			return newHead;
		}

		public static void PrintContent(Coord WhereYouWantIt, char charToBePrinted) {

			Console.ForegroundColor = ConsoleColor.Yellow;
			Console.SetCursorPosition(WhereYouWantIt.X, WhereYouWantIt.Y);
			Console.Write(charToBePrinted);

		}

		public static bool SpawnNewHeadAndApple(Coord snakeHead, List<Coord> snakeContent, Coord newHead, bool spotIsOccupied,
													Coord snakeTail, Coord coord, Random rng, int boardWidth, int boardHeight) {

			PrintContent(snakeHead, '0');
			snakeContent.Add(newHead);
			PrintContent(newHead, '@');

			if (!spotIsOccupied) {
				PrintContent(snakeTail, ' ');
			}
			if (spotIsOccupied) {
				ApplesObject apple = new ApplesObject(rng, coord, boardHeight, boardWidth, snakeContent);
				return spotIsOccupied = false;
			}
			return spotIsOccupied;
		}

		public static bool DidYouHitSomething(bool spotIsOccupied, bool gameOver, List<Coord> snakeContent, Coord newHead,
                                                int boardWidth, int boardHeight) {

			if (newHead.X < 0 || newHead.X >= boardWidth)
				gameOver = true;

			if (newHead.Y < 0 || newHead.Y >= boardHeight)
				gameOver = true;

			if (snakeContent.Count + 1 >= boardWidth * boardHeight)
				// No more room to place apples -- game over.
				gameOver = true;

			if (!spotIsOccupied) 
				snakeContent.RemoveAt(0);
				foreach (Coord x in snakeContent)
					if (x.X == newHead.X && x.Y == newHead.Y) {
						// Death by accidental self-cannibalism.
						gameOver = true;
						break;
					}
			return gameOver;
		}

		public static bool IsSpawnPointInsideSnake(Coord coord, int boardWidth, int boardHeight, 
													List<Coord> snakeContent, Random rng) {
			
			coord.X = rng.Next(0, boardWidth); coord.Y = rng.Next(0, boardHeight);
			var spawnpoint = SpawnCheck(snakeContent, coord);

			return spawnpoint;
		}

		public static bool SpawnCheck(List<Coord> snakeContent, Coord coord) {
			var spawnpoint = true;

			foreach (Coord i in snakeContent)
				if (i.X == coord.X && i.Y == coord.Y) {
					spawnpoint = false;
					return spawnpoint;
				}
			return spawnpoint;
		}
	}
}