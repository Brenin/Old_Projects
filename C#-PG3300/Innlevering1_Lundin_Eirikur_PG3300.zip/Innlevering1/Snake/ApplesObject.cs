﻿// Refactored by Eirikur Lundin for PG3300 - Software Design

using System;
using System.Collections.Generic;

namespace Snake {
	class ApplesObject {

		public ApplesObject() {

		}

		public ApplesObject(Random rng, Coord coord, int boardHeight, int boardWidth, List<Coord> snakeContent) {

			while (true) {
				coord.X = rng.Next(0, boardWidth); coord.Y = rng.Next(0, boardHeight);
				var spotIsOccupied = HelpfullMethods.SpawnCheck(snakeContent, coord);

				if (spotIsOccupied) {
					Console.ForegroundColor = ConsoleColor.Green;
					Console.SetCursorPosition(coord.X, coord.Y);
					Console.Write("$");
					break;
				}
			}
		}
	}
}