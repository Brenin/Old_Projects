﻿// Refactored by Eirikur Lundin for PG3300 - Software Design

namespace Snake {
	class Coord {

		private int _x;
		private int _y;
		
		public int X { set { this._x = value; } get { return this._x; } }
		public int Y { set { this._y = value; } get { return this._y; } }

		public Coord(int x = 0, int y = 0) { X = x; Y = y; }

		public Coord(Coord input) {  _x = input._x; _y = input._y; }
	}
}