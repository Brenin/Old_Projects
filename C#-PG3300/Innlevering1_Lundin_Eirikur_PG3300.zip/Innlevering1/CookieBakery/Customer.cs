﻿// Created by Eirikur Lundin for PG3300

namespace CookieBakery {
	public class Customer {

		private string _customerName;

		public Customer(string name) {
			_customerName = name;
		}

		public string name { get { return _customerName; } set { this._customerName = value; } }

		public override string ToString() {
			return this._customerName;
		}
	}
}