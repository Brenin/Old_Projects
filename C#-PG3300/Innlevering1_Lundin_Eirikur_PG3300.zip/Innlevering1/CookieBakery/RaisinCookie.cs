﻿// Created by Eirikur Lundin for PG3300

namespace CookieBakery {
	class RaisinCookie : BasicCookie, ICookie {
		public override int bakingTime() {
			return 200;
		}

		public override string getDescription() {
			return "Cookie with raisins";
		}

		public override string getName() {
			return "Raisin cookie";
		}
	}
}