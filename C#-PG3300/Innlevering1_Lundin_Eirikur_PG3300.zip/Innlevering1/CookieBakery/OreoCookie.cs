﻿// Created by Eirikur Lundin for PG3300

namespace CookieBakery {
	class OreoCookie : BasicCookie, ICookie {
		public override int bakingTime() {
			return 500;
		}

		public override string getDescription() {
			return "A delicious cookie made with chunks of Oreo";
		}

		public override string getName() {
			return "Oreo cookie";
		}
	}
}