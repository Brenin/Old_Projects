﻿// Created by Eirikur Lundin for PG3300

using System.Threading;

namespace CookieBakery {
	class CustomerClass {

		Customer nr1 = new Customer("");
		private Bakery _bakery;
		private int _pollingIntervalInMilliseconds;

		public CustomerClass(string name, int pollingIntervalInMilliseconds, Bakery bakery) {
			nr1 = new Customer(name);
			_bakery = bakery;
			_pollingIntervalInMilliseconds = pollingIntervalInMilliseconds;
		}

		public void DoPurchase() {
			for (int i = 0; i < 100; i++) {
				_bakery.SellCookieTo(nr1);
				Thread.Sleep(_pollingIntervalInMilliseconds);
			}
		}
	}
}