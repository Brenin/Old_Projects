﻿// Created by Eirikur Lundin for PG3300

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;

namespace CookieBakery {
	class Program {

		static void Main(string[] args) {

			var bakery = new Bakery();
			Thread[] threads = new Thread[4];
			CustomerClass customerNr1 = new CustomerClass("Fred", 300, bakery);
			CustomerClass customerNr2 = new CustomerClass("Ted", 200, bakery);
			CustomerClass customerNr3 = new CustomerClass("Greg", 600, bakery);
			List<ICookie> cookiesToBake = new List<ICookie>() {
				new ChocolateCookie(),
				new OreoCookie(),
				new ChocolateCookie(),
				new ChocolateCookie(),
				new RaisinCookie(),
				new DarkChocolateCookie(),
				new OreoCookie(),
				new DarkChocolateCookie(),
				new DarkChocolateCookie(),
				new OreoCookie(),
				new ChocolateCookie(),
				new OreoCookie(),
				new OreoCookie(),
				new ChocolateCookie(),
				new OreoCookie(),
				new RaisinCookie(),
				new DarkChocolateCookie(),
				new RaisinCookie()
			};

			threads[0] = new Thread(new ThreadStart(customerNr1.DoPurchase));
			threads[1] = new Thread(new ThreadStart(customerNr2.DoPurchase));
			threads[2] = new Thread(new ThreadStart(customerNr3.DoPurchase));

			for (int k = 0; k < 3; k++) {
				threads[k].Start();
			}

			bakery.StartBaking(cookiesToBake);
		}
	}

	public class Bakery {
		private object lockingObject = new object();
		private readonly ConcurrentQueue<ICookie> _cookieJar = new ConcurrentQueue<ICookie>();
		private List<ICookie> _cookiesToBake;
		private int _soldCookies = 1;

		public void StartBaking(List<ICookie> cookiesToBake) {
			_cookiesToBake = cookiesToBake;
			Thread t = new Thread(Baking);
			t.Start();
		}

		public void Baking() {
			int counter = 1;
			foreach (var cookie in _cookiesToBake) {
				AddCookie(cookie);
				Console.WriteLine("Baked cookie nr " + counter + " It's a " + cookie.getName());
				counter++;
				Thread.Sleep(cookie.bakingTime());
			}
		}

		private void AddCookie(ICookie cookie) {
			lock (lockingObject) {
				_cookieJar.Enqueue(cookie);
			}
		}

		public void SellCookieTo(Customer customer) {
			lock (lockingObject) {
				ICookie cookie;
				if (_cookieJar.TryDequeue(out cookie)) {
					Console.WriteLine("Sold cookie nr " + _soldCookies + " a " + cookie.getName() + " to " + customer.name + "\n");
					_soldCookies++;
				}
			}
		}
	}
}