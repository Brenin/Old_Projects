﻿// Created by Eirikur Lundin for PG3300

namespace CookieBakery {
	abstract class BasicCookie {

		public abstract int bakingTime();

		public abstract string getName();

		public abstract string getDescription();

	}
}