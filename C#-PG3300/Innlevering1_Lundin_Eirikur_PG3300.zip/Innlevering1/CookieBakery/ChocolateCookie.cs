﻿// Created by Eirikur Lundin for PG3300

using System;

namespace CookieBakery {
	class ChocolateCookie : BasicCookie, ICookie {
		public override int bakingTime() {
			return 300;
		}

		public override string getDescription() {
			return "A delicious cookie made with chocolate";
		}

		public override string getName() {
			return "Chocolate cookie";
		}
	}
}