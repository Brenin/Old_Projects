﻿// Created by Eirikur Lundin for PG3300

using System;

namespace CookieBakery {
	class DarkChocolateCookie : BasicCookie, ICookie {
		public override int bakingTime() {
			return 400;
		}

		public override string getDescription() {
			return "A delicious cookie made with dark chocolate";
		}

		public override string getName() {
			return "Dark chocolate cookie";
		}
	}
}