﻿// Created by Eirikur Lundin for PG3300

namespace CookieBakery {
	abstract class CookieChooser : ICookie {

		private ICookie original;

		protected CookieChooser(ICookie original) {
			this.original = original;
		}

		public int bakingTime() {
			return original.bakingTime();
		}

		public virtual string getDescription() {
			return original.getDescription();
		}

		public virtual string getName() {
			return original.getName();
		}
	}
}