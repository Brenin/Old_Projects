﻿// Created by Eirikur Lundin for PG3300

namespace CookieBakery {
	public interface ICookie {

		int bakingTime();

		string getName();

		string getDescription();

	}
}