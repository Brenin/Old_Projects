package printing;

public class PrintStars {
	public void printStars(){
		for(int i = 0; i < 50; i++){
			System.out.print("*");
		}
	}
}
