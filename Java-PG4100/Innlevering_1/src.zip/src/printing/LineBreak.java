package printing;

public class LineBreak {
	public void lineBreak(){
		System.out.print("\n");
	}
}
