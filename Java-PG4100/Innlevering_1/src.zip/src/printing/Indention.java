package printing;

public class Indention {
	public String tabs(){
		return "\t\t\t\t\t\t\t\t\t";
	}
}
