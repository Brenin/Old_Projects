package logic;

public class Logger {
	public void logError(Exception e){
		e.printStackTrace();
	}
}
